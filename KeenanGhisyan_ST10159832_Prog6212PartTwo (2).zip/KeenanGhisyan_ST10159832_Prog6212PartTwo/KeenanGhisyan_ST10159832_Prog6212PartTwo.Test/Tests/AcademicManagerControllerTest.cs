﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers;
using KeenanGhisyan_ST10159832_Prog6212PartTwo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Test.Tests
{
    public class AcademicManagerControllerTests
    {
        private readonly Mock<ILogger<AcademicManagerController>> _loggerMock;
        private readonly AcademicManagerController _controller;

        public AcademicManagerControllerTests()
        {
            // Mock logger
            _loggerMock = new Mock<ILogger<AcademicManagerController>>();
            _controller = new AcademicManagerController(_loggerMock.Object);
        }

        [Fact]
        public void ProcessClaim_ApproveAction_ChangesStatusToApproved()
        {
            // Arrange
            var claimId = 1;
            LecturerController.ClaimsList.Add(new ClaimViewModel { ClaimId = claimId, ClaimStatus = "Pending" });

            // Act
            var result = _controller.ProcessClaim(claimId, "approve") as RedirectToActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("ManageProcessedClaims", result.ActionName);
            Assert.Equal("Approved by Academic Manager", LecturerController.ClaimsList.First(c => c.ClaimId == claimId).ClaimStatus);
        }

        [Fact]
        public void ProcessClaim_DeclineAction_ChangesStatusToDeclined()
        {
            // Arrange
            var claimId = 1;
            LecturerController.ClaimsList.Add(new ClaimViewModel { ClaimId = claimId, ClaimStatus = "Pending" });

            // Act
            var result = _controller.ProcessClaim(claimId, "decline") as RedirectToActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("ManageProcessedClaims", result.ActionName);
            Assert.Equal("Declined by Academic Manager", LecturerController.ClaimsList.First(c => c.ClaimId == claimId).ClaimStatus);
        }

        [Fact]
        public void ProcessClaim_InvalidClaimId_ReturnsNotFound()
        {
            // Act
            var result = _controller.ProcessClaim(999, "approve") as NotFoundResult;

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public void ProcessClaim_ExceptionDuringProcessing_LogsErrorAndRedirects()
        {
            // Arrange
            var claimId = 1;
            _controller.ModelState.AddModelError("test", "test error"); // Simulate an error condition

            // Act
            var result = _controller.ProcessClaim(claimId, "approve") as RedirectToActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("ManageProcessedClaims", result.ActionName);
            _loggerMock.Verify(
                logger => logger.LogError(It.IsAny<Exception>(), It.IsAny<string>()),
                Times.Once
            );
        }
    }
}
