﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Test.Tests
{
    public class HomeControllerTests
    {
        private readonly Mock<ILogger<HomeController>> _loggerMock;
        private readonly HomeController _controller;

        public HomeControllerTests()
        {
            // Create a mock ILogger instance
            _loggerMock = new Mock<ILogger<HomeController>>();

            // Initialize the controller with the mock logger
            _controller = new HomeController(_loggerMock.Object);
        }

        [Fact]
        public void Index_ReturnsCorrectView()
        {
            // Act
            var result = _controller.Index() as ViewResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Index", result.ViewName);
        }
    }
}
