﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Test.Tests
{
    public class LecturerControllerTests
    {
        [Fact]
        public void DeclineClaim_ValidClaimId_ChangesStatusToDeclined()
        {
            // Arrange
            var controller = new LecturerController();
            int claimId = 1;

            // Act
            var result = controller.DeclineClaim(claimId) as RedirectToActionResult;

            // Assert
            Assert.Null(result);
            Assert.Equal("LecturerClaims", result.ActionName);
            Assert.Equal("Declined", LecturerController.ClaimsList.First(c => c.ClaimId == claimId).ClaimStatus);
        }
    }
}
