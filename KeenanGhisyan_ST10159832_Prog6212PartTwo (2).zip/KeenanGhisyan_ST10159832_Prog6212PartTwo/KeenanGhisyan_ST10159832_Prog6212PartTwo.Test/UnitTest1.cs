namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}