﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers
{
    public class AcademicManagerController : Controller
    {
        private readonly LecturerContext _context; // Database context
        private readonly ILogger<AcademicManagerController> _logger; // Logger

        // Inject the database context and logger through the constructor
        public AcademicManagerController(LecturerContext context, ILogger<AcademicManagerController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: AcademicManagerDetails
        public IActionResult AcademicManagerDetails()
        {
            return View();
        }

        // POST: AcademicManagerDetails
        [HttpPost]
        public IActionResult AcademicManagerDetails(AcademicManagerClaimsViewModel model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.UserId) && model.UserId.StartsWith("0"))
                {
                    if (model.Password == "admin")
                    {
                        // Redirect to the processed claims page on valid credentials
                        return RedirectToAction("ManageProcessedClaims");
                    }
                    else
                    {
                        // Password is invalid
                        ModelState.AddModelError("Password", "The password is incorrect. Please try again.");
                    }
                }
                else
                {
                    // User ID is invalid
                    model.UserId = string.Empty; // Clear the UserId field
                    ModelState.AddModelError("UserId", "Invalid User ID. Please try again.");
                }

                return View(model); // Return the view with validation errors
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the Academic Manager details.");
                ModelState.AddModelError("", "An unexpected error occurred. Please try again later.");
                return View(model);
            }
        }

        // GET: Display claims processed by the Programme Coordinator
        public async Task<IActionResult> ManageProcessedClaims() //https://youtu.be/KS7tqqoNFOw?si=5TJQimoeyz7-9WmW
        {
            try
            {
                // Fetch claims that are pending Academic Manager approval
                var processedClaims = await _context.Claims
                    .Where(c => c.ClaimStatus == "Pending Academic Manager Approval" ||
                                c.ClaimStatus == "Declined by Coordinator")
                    .ToListAsync();

                var viewModel = new AcademicManagerClaimsViewModel
                {
                    ProcessedClaims = processedClaims
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving processed claims.");
                ModelState.AddModelError("", "An unexpected error occurred while fetching claims. Please try again later.");
                return View(new AcademicManagerClaimsViewModel());
            }
        }

        // GET: Review claim details before approval/decline
        public async Task<IActionResult> ReviewClaim(int claimId)
        {
            try
            {
                // Fetch claim by ID
                var claim = await _context.Claims.FirstOrDefaultAsync(c => c.ClaimId == claimId);

                if (claim == null)
                {
                    return NotFound();
                }

                return View(claim);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while reviewing the claim with ID {claimId}.");
                return NotFound();
            }
        }

        // POST: Approve or Decline the claim
        [HttpPost]
        public async Task<IActionResult> ProcessClaim(int claimId, string actionType)
        {
            try
            {
                // Fetch claim by ID
                var claim = await _context.Claims.FirstOrDefaultAsync(c => c.ClaimId == claimId);
                if (claim == null)
                {
                    return NotFound();
                }

                // Update the claim status based on the actionType
                if (actionType == "approve")
                {
                    claim.ClaimStatus = "Approved by Academic Manager";
                }
                else if (actionType == "decline")
                {
                    claim.ClaimStatus = "Declined by Academic Manager";
                }

                // Save changes to the database
                await _context.SaveChangesAsync();

                return RedirectToAction("ManageProcessedClaims");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while processing the claim with ID {claimId}.");
                ModelState.AddModelError("", "An unexpected error occurred while processing the claim. Please try again later.");
                return RedirectToAction("ManageProcessedClaims");
            }
        }
    }
}
