﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers
{
    public class HRController : Controller //https://youtu.be/AMzaPrchvrc?si=Lgl5iz7ix9U3jilv
    {
        private readonly LecturerContext _context;

        public HRController(LecturerContext context)
        {
            _context = context;
        }

        public IActionResult GenerateReport()
        {
            // Optionally, you can load required data here (e.g., Lecturer list, claim types) for the report generation form
            var lecturers = _context.Lecturers.ToList();
            ViewBag.Lecturers = new SelectList(lecturers, "LecturerId", "LecturerName");

            return View();
        }

        // Action to handle the form submission (filtering data and generating the report)
        [HttpPost]
        public IActionResult GenerateReport(DateTime startDate, DateTime endDate, string lecturerId)
        {
            // Filter data based on user input
            var claims = _context.Claims
                                 .Where(c => c.StartDate >= startDate && c.EndDate <= endDate)
                                 .Where(c => string.IsNullOrEmpty(lecturerId) || c.LecturerId == lecturerId)
                                 .ToList();

            // Generate the report (you could use a reporting library like Crystal Reports, SSRS, or manually create a report)
            // Pass the filtered claims to the report view
            return View("ReportResult", claims); // Assume ReportResult is the view that displays the report
        }


        // HR Dashboard
        public IActionResult HRDashboard()
        {
            var pendingClaims = _context.Claims
                .Include(c => c.Lecturer) // Include lecturer details
                .Where(c => c.ClaimStatus == "Pending")
                .ToList();

            var lecturers = _context.Lecturers.ToList();

            // Pass both lists to the view
            var model = (pendingClaims, lecturers);
            return View(model);
        }

        // Approve a claim
        [HttpPost]
        public IActionResult ApproveClaim(int id)
        {
            try
            {
                var claim = _context.Claims.FirstOrDefault(c => c.ClaimId == id);

                if (claim != null)
                {
                    claim.ClaimStatus = "Approved";
                    claim.ProcessedBy = User.Identity?.Name ?? "Unknown User";
                    _context.Claims.Update(claim); // Explicitly track the entity
                    _context.SaveChanges();
                }

                return RedirectToAction("HRDashboard");
            }
            catch (Exception ex)
            {
                // Log exception (using ILogger or another logging system)
                return RedirectToAction("Error"); // Redirect to an error page
            }
        }

        // Update Lecturer Information
        [HttpPost]
        public IActionResult UpdateLecturer(string LecturerId, string LecturerName, string LecturerEmail)
        {
            try
            {
                var lecturer = _context.Lecturers.FirstOrDefault(l => l.LecturerId == LecturerId);

                if (lecturer != null)
                {
                    lecturer.LecturerName = LecturerName;
                    lecturer.LecturerEmail = LecturerEmail;
                    _context.Lecturers.Update(lecturer); // Explicitly track the entity
                    _context.SaveChanges();
                }

                return RedirectToAction("HRDashboard");
            }
            catch (Exception ex)
            {
                // Log exception
                return RedirectToAction("Error");
            }
        }

            // Upload Supporting Documents
            [HttpPost]
        public IActionResult UploadSupportingDocument(int claimId, IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                var uploadedFile = new UploadedFile
                {
                    ClaimId = claimId,
                    FileName = file.FileName,
                    ContentType = file.ContentType,
                    FileContent = ConvertToByteArray(file)
                };

                _context.UploadedFiles.Add(uploadedFile);
                _context.SaveChanges();
            }

            return RedirectToAction("Dashboard");
        }

        // Generate Invoice for Approved Claims
        public IActionResult GenerateInvoice()
        {
            var approvedClaims = _context.Claims
                .Include(c => c.Lecturer) // Include lecturer details for the invoice
                .Where(c => c.ClaimStatus == "Approved")
                .ToList();

            var invoice = new Invoice
            {
                InvoiceDate = DateTime.Now,
                Claims = approvedClaims,
                TotalAmount = approvedClaims.Sum(c => c.PayableAmount)
            };

            _context.Invoices.Add(invoice);
            _context.SaveChanges();

            return View(invoice);
        }

        // View Uploaded Documents
        public IActionResult ViewSupportingDocuments(int claimId)
        {
            var documents = _context.UploadedFiles
                .Where(uf => uf.ClaimId == claimId)
                .ToList();

            return View(documents);
        }

        // Helper Method: Convert File to Byte Array
        private byte[] ConvertToByteArray(IFormFile file)
        {
            using (var memoryStream = new MemoryStream())
            {
                file.CopyTo(memoryStream);
                return memoryStream.ToArray();
            }
        }
    }
}

