﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers
{
    public class LecturerController : Controller
    {
        private readonly LecturerContext _context; // Use the correct database context

        public LecturerController(LecturerContext context)
        {
            _context = context;
        }



        public IActionResult LecturerDetails()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SubmitLecturerDetails(string lecturerId, string lecturerName, string lecturerEmail)
        {
            var lecturer = new LecturerViewModel
            {
                LecturerId = lecturerId,
                LecturerName = lecturerName,
                LecturerEmail = lecturerEmail
            };

            // Add to the database
            _context.Lecturers.Add(lecturer);
            await _context.SaveChangesAsync();

            return RedirectToAction("LecturerInfo");
        }

        public IActionResult LecturerInfo()
        {
            return View();
        }

        [HttpPost] //https://youtu.be/yFapkpBlD_s?si=ZC4q4J-tf5L5c-zX used to save data in database 
        public async Task<IActionResult> SubmitWorkDetails(
            double hoursWorked,
            double hourlyRate,
            DateTime startDate,
            DateTime endDate,
            string moduleCode,
            IFormFile supportingDocument)

        {
            try
            {
                // Validate dates
                if (startDate > DateTime.Now || endDate > DateTime.Now || endDate > startDate.AddMonths(4))
                {
                    ModelState.AddModelError("DateValidation", "Invalid date range.");
                }

                // Validate hours worked and hourly rate
                if (hoursWorked < 0 || hoursWorked > 44)
                    ModelState.AddModelError("HoursWorked", "Hours worked must be between 0 and 44.");

                if (hourlyRate <= 0 || hourlyRate > 1500)
                    ModelState.AddModelError("HourlyRate", "Hourly rate must be greater than 0 and less than 1500.");

                // Validate file upload
                string filePath = null;
                if (supportingDocument != null)
                {
                    const long maxFileSize = 6 * 1024 * 1024;
                    if (supportingDocument.Length > maxFileSize)
                        ModelState.AddModelError("SupportingDocument", "The file size must not exceed 6MB.");

                    var allowedExtensions = new[] { ".pdf", ".docx", ".xlsx" };
                    var fileExtension = Path.GetExtension(supportingDocument.FileName).ToLower();
                    if (!allowedExtensions.Contains(fileExtension))
                        ModelState.AddModelError("SupportingDocument", "Invalid file type.");

                    if (ModelState.IsValid)
                    {
                        // Save file
                        var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                        if (!Directory.Exists(uploadsFolder))
                            Directory.CreateDirectory(uploadsFolder);

                        filePath = Path.Combine(uploadsFolder, supportingDocument.FileName);
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await supportingDocument.CopyToAsync(stream);
                        }
                    }
                }

                if (!ModelState.IsValid)
                    return View("LecturerInfo");

                // Create and save claim
                var lecturer = await _context.Lecturers.FirstOrDefaultAsync(); // Fetch a lecturer from the database
                var claim = new ClaimViewModel
                {
                    LecturerId = lecturer.LecturerId,
                    LecturerName = lecturer.LecturerName,
                    LecturerEmail = lecturer.LecturerEmail,
                    HoursWorked = hoursWorked,
                    HourlyRate = hourlyRate,
                    TotalAmount = hoursWorked * hourlyRate,
                    PayableAmount = hoursWorked * hourlyRate,
                    ClaimStatus = "Pending Coordinator Approval",
                    StartDate = startDate,
                    EndDate = endDate,
                    ModuleCode = moduleCode,
                    SupportingDocumentUrl = filePath != null ? $"/uploads/{Path.GetFileName(filePath)}" : null
                };

                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();

                return RedirectToAction("LecturerClaims");
            }
            catch
            {
                ModelState.AddModelError("", "An error occurred while processing the request.");
                return View("LecturerInfo");
            }
        }

        public async Task<IActionResult> LecturerClaims()
        {
            var claims = await _context.Claims.ToListAsync();
            return View(claims);
        }

        public async Task<IActionResult> ViewClaim(int claimId)
        {
            var claim = await _context.Claims.Include(c => c.SupportingDocuments)
                                             .FirstOrDefaultAsync(c => c.ClaimId == claimId);
            if (claim == null)
                return NotFound();

            return View(claim);
        }

        [HttpPost]
        public async Task<IActionResult> UploadDocument(int claimId, IFormFile file)
        {
            try
            {
                // Find the claim in the database
                var claim = await _context.Claims.Include(c => c.SupportingDocuments)
                                                 .FirstOrDefaultAsync(c => c.ClaimId == claimId);
                if (claim == null)
                    return NotFound();

                if (file != null && file.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        file.CopyTo(ms);
                        var fileBytes = ms.ToArray();

                        // Create an UploadedFile object
                        var uploadedFile = new UploadedFile
                        {
                            FileName = file.FileName,
                            FileContent = fileBytes,
                            ContentType = file.ContentType
                        };

                        // Add the file to the claim's SupportingDocuments
                        claim.SupportingDocuments.Add(uploadedFile);
                    }

                    await _context.SaveChangesAsync(); // Save changes
                }

                return RedirectToAction("ViewClaim", new { claimId });
            }
            catch
            {
                ModelState.AddModelError("", "An error occurred while uploading the document.");
                return View("Error");
            }
        }

        public async Task<IActionResult> DownloadDocument(int claimId, string fileName)
        {
            try
            {
                // Find the claim in the database
                var claim = await _context.Claims.Include(c => c.SupportingDocuments)
                                                 .FirstOrDefaultAsync(c => c.ClaimId == claimId);
                if (claim == null)
                    return NotFound();

                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", fileName);
                if (!System.IO.File.Exists(filePath))
                    return NotFound();

                var contentType = fileName.EndsWith(".pdf") ? "application/pdf" :
                                  fileName.EndsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" :
                                  fileName.EndsWith(".xlsx") ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" :
                                  "application/octet-stream";

                var fileBytes = System.IO.File.ReadAllBytes(filePath);
                return File(fileBytes, contentType, fileName);
            }
            catch
            {
                ModelState.AddModelError("", "An error occurred while downloading the document.");
                return View("Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> ApproveClaim(int claimId)
        {
            var claim = await _context.Claims.FirstOrDefaultAsync(c => c.ClaimId == claimId);
            if (claim != null)
            {
                claim.ClaimStatus = "Approved";
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("LecturerClaims");
        }

        [HttpPost]
        public async Task<IActionResult> DeclineClaim(int claimId)
        {
            var claim = await _context.Claims.FirstOrDefaultAsync(c => c.ClaimId == claimId);
            if (claim != null)
            {
                claim.ClaimStatus = "Declined";
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("LecturerClaims");
        }

        [HttpPost]
        public async Task<IActionResult> MarkAsReviewing(int claimId)
        {
            var claim = await _context.Claims.FirstOrDefaultAsync(c => c.ClaimId == claimId);
            if (claim != null)
            {
                claim.ClaimStatus = "Reviewing";
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("LecturerClaims");
        }
    }
}
