﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Models
{
    public class ClaimViewModel
    {
        [Key]
        public int ClaimId { get; set; }

        [Required(ErrorMessage = "Lecturer ID is required.")]
        [ForeignKey("Lecturer")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "Lecturer ID must be exactly 4 digits.")]
        public string LecturerId { get; set; }

        public LecturerViewModel Lecturer { get; set; } // Navigation property for Lecturer

        public string LecturerName { get; set; }
        public string LecturerEmail { get; set; }

        [Required(ErrorMessage = "Hours Worked is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Hours Worked must be a positive number.")]
        public double HoursWorked { get; set; }

        [Required(ErrorMessage = "Hourly Rate is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Hourly Rate must be a positive number.")]
        public double HourlyRate { get; set; }

        public string SupportingDocumentUrl { get; set; }
        public string ClaimStatus { get; set; }
        public string ProcessedBy { get; set; } // Name of who processed the claim
        public string ApproverRole { get; set; } // Role of who processed (Coordinator or Manager)

        [Required(ErrorMessage = "Total Amount is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Total Amount must be a positive number.")]
        public double TotalAmount { get; set; }

        public double PayableAmount { get; set; }

        [Column(TypeName = "date")] // Ensures only date is stored
        public DateTime StartDate { get; set; } = DateTime.Now;

        [Column(TypeName = "date")]
        public DateTime EndDate { get; set; } = DateTime.Now;

        public string ModuleCode { get; set; }
        public int InvoiceId { get; set; }

        [NotMapped]
        public IFormFile SupportingDocument { get; set; } // For file uploads, not stored in DB

        public List<UploadedFile> SupportingDocuments { get; set; } = new List<UploadedFile>();
    }

    public class UploadedFile
    {
        [Key]
        public int FileId { get; set; } // Primary key for the file

        public string FileName { get; set; } // The name of the file
        public byte[] FileContent { get; set; } // The file content in bytes
        public string ContentType { get; set; } // The MIME type of the file

        [ForeignKey("Claim")]
        public int ClaimId { get; set; } // Foreign key to associate with ClaimViewModel

        public ClaimViewModel Claim { get; set; } // Navigation property to the claim
    }
}

