﻿using System.ComponentModel.DataAnnotations;
using System.Security.Claims;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Models
{
    public class Invoice
    {
        [Key]
        public int InvoiceId { get; set; }

        public DateTime InvoiceDate { get; set; }

        public double TotalAmount { get; set; }

        public ICollection<ClaimViewModel> Claims { get; set; } = new List<ClaimViewModel>();
    }
}
