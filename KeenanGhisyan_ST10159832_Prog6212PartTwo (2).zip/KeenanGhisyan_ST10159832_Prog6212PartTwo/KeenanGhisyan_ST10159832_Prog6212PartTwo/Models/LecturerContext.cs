﻿using Microsoft.EntityFrameworkCore;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Models
{
    //https://youtu.be/ZX12X-ALwGA?si=Ot5GYht4wxE_32cd video was used for creating databse 
    public class LecturerContext : DbContext
    {
        public LecturerContext(DbContextOptions<LecturerContext> options) : base(options) { }

        // DbSet properties for your entity classes
        public DbSet<ClaimViewModel> Claims { get; set; }
        public DbSet<LecturerViewModel> Lecturers { get; set; }
        public DbSet<UploadedFile> UploadedFiles { get; set; }
        public DbSet<Invoice> Invoices { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           
            modelBuilder.Entity<ClaimViewModel>()
                .HasOne(c => c.Lecturer) 
                .WithMany(l => l.Claims) 
                .HasForeignKey(c => c.LecturerId)
                .OnDelete(DeleteBehavior.Cascade); 


            modelBuilder.Entity<UploadedFile>()
                .HasOne(uf => uf.Claim)
                .WithMany(c => c.SupportingDocuments)
                .HasForeignKey(uf => uf.ClaimId)
                .OnDelete(DeleteBehavior.Cascade);


            modelBuilder.Entity<Invoice>()
                .HasMany(i => i.Claims)
                .WithOne()
                .HasForeignKey(c => c.InvoiceId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }
    }
}
