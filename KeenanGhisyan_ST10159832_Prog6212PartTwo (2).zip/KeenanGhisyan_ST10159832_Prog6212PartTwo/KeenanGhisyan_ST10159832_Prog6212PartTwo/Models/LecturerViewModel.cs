﻿using System.ComponentModel.DataAnnotations;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Models
{
    public class LecturerViewModel
    {
        [Key]
        [Required(ErrorMessage = "Lecturer ID is required.")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "Lecturer ID must be exactly 4 digits.")]
        public string LecturerId { get; set; }

        [Required(ErrorMessage = "Lecturer Name is required.")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Lecturer Name must only contain letters.")]
        public string LecturerName { get; set; }

        [Required(ErrorMessage = "Lecturer Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address.")]
        public string LecturerEmail { get; set; }

        public ICollection<ClaimViewModel> Claims { get; set; } = new List<ClaimViewModel>();
    }
}
